//const fs = require('pn');
const D3Node = require('./d3-node.js');
const d3 = require('d3');
//,q = require("d3-queue");
//const markup = '<div id="container"><h2>Bar Chart</h2><div id="chart"></div></div>';


//var options = {selector:'#chart', svgStyles: '/public/stylesheets/style.css', container:markup};
var d3n = new D3Node(/*options*/);
//d3n.html();
//var svg = d3n.createSVG().append('g')
//var svgText = d3.createSVG().append()
//var q = d3.queue();



//router.get('/', function(req, res) {
module.exports.graphRender = function (userData, callback){

			/*var yKeys = Object.values(data.votes[0]); //number
		var yA = Object.values(data.votes[0].ans_a);
		var yB = Object.values(data.votes[0].ans_b);
		var yDomain = [yA, yB];
		var question = data.polls[0].poll_q;
		*/
		//var votes = data.votes;
		var yKeys;

		var valA;
		var valB;
		if (userData.votes == null || userData.votes[0] == null || userData.votes[0] == undefined ) {
			console.log(votes)
			valA = 0, valB = 0;
		} else {
			var votes = userData.votes;
			//data = data.votes[0];
			valA = votes[0].ans_a, valB = votes[0].ans_b;
			var data = [valA, valB];
			var yMax = Math.max(data);
			var index = data.length; //this needs to precede:
			var answerA = data.polls[0].ans_a; //string
			var answerB = data.polls[0].ans_b; //string


			var alph = ["a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"];
			var num;

			dblength = index;
			var alphInd;
			if (dblength >= alph.length) { //start over at 0
				num = dblength % alph.length;
				alphInd = alph[num]
			} else {
				num = dblength+1;
				alphInd = 0;
			}

			if (num > alph.length) {
				alphInd++; //increment alphabet char
			}
			var uniqueId = alph[alphInd]+""+num; //id for saving graph. No encrypt.
			var xDomain = [answerA, answerB];
			var margin = {top: 80, right: 180, bottom: 80, left: 180},
			    width = 400 - margin.left - margin.right,
			    height = 300 - margin.top - margin.bottom;

			var x = d3_scale.scaleOrdinal()
			    .range([0, width], .1, .3);

			var y = d3_scale.scaleLinear()
			    .range([height, 0]);

			var xAxis = d3.axisBottom()
			    .scale(x);

			var yAxis = d3.axisLeft()
			    .scale(y)
			    .ticks(8, "%");

			var svg = d3n.createSVG()
				  .attr("width", width + margin.left + margin.right)
				  .attr("height", height + margin.top + margin.bottom)
				  .append("g")
				.attr("transform", "translate(" + margin.left + "," + margin.top + ")");
			/*var xAxis = d3.ordinal.scale()
				.range([margin.left, width-margin.right])
				.domain([answerA, answerB]);*/


			x.domain(xDomain.map(function(d){
				return d; //?
			}));
			y.domain([0, yMax]);

		  	svg.append("text")
		      .attr("class", "title")
		      .attr("x", xDomain)
		      .attr("y", -26)
		      .text(question);

		  	svg.append("g")
		      .attr("class", "x axis")
		      .attr("transform", "translate(0," + height + ")")
		      .call(xAxis)
		    .selectAll(".tick text")
		      .call(wrap, x.rangeBand());

		  	svg.append("g")
		      .attr("class", "y axis")
		      .call(yAxis);

		  	svg.selectAll(".bar")
		      .data(data)
		    .enter().append("rect")
		      .attr("class", "bar")
		      .attr("x", function(d, i) { return x(d[i]); } )
		      .attr("width", x.rangeBand())
		      .attr("y", function(d, i) { return y(d[i]); })
		      .attr("height", function(d, i) { return height - y(d[i]); });

			/*var uniqueId = uniqueId; 
			fs.writeFile('graphs/'+user_id+'/'+uniqueId+'.html', d3n.html(), function () {
			    console.log('>> Done. Open "graphs/'+user_id+'/'+uniqueId+'.html" in a web browser');
			  });
			var graphPng = JSON.stringify('graphs/'+user_id+'/'+uniqueId+'.png');
			var svgBuffer = new Buffer(d3n.svgString(), 'utf-8');
			  svg2png(svgBuffer)
			    .then(buffer => fs.writeFile('graphs/'+user_id+'/'+uniqueId+'.png', buffer))
			    .catch(e => console.error('ERR:', e))
			    .then(err => console.log('>> Exported: "graphs/'+user_id+'/'+uniqueId+'.png"'));
				*/
			return callback(null, JSON.stringify(d3n));						
		}
     	//res.render('poll', { svg: 'Group Practices', 'graphs/'+user_id+'/'+uniqueId+'.png' });

    }

};

//module.exports = router;