var express = require('express');
var path = require('path');
var _ = require('underscore');
var routes = require('./routes')
var dotenv = require('dotenv');
var bodyParser = require('body-parser');
var cookieParser = require('cookie');
var mongoose = require('mongoose');
var session = require('express-session');
var MongoStore = require('connect-mongo')(session); //let connect-mongo access session
var User = require('./models/user');
var passport = require('passport');
var Auth0Strategy = require('passport-auth0');
var jwt = require('express-jwt');
dotenv.load();

var index = require('./routes/index');

// This will configure Passport to use Auth0
var strategy = new Auth0Strategy({
    domain:       process.env.AUTH0_DOMAIN,
    clientID:     process.env.AUTH0_CLIENT_ID,
    clientSecret: process.env.AUTH0_CLIENT_SECRET,
    callbackURL:  process.env.AUTH0_CALLBACK_URL || 'http://localhost:8080/callback'
  }, function(accessToken, refreshToken, extraParams, profile, done) {
    // accessToken is the token to call Auth0 API (not needed in the most cases)
    // extraParams.id_token has the JSON Web Token
    // profile has all the information from the user
    return done(null, profile);
  });

passport.use(strategy);

// you can use this section to keep a smaller payload
passport.serializeUser(function(user, done) {
  done(null, user);
});

passport.deserializeUser(function(user, done) {
  done(null, user);
});


var uri = process.env.DEVDB || process.env.MONGODB_URI;

mongoose.connect(uri);
var db = mongoose.connection;
db.on('error', console.error.bind(console, 'connection error:'));

var app = express();

app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.json());
var urlencodedParser = bodyParser.urlencoded({ extended: false })
app.use(urlencodedParser);

// use sessions for tracking logins
app.use(session({
	secret: 'fccftw',
	resave: true,
	saveUninitialized: true,
	store: new MongoStore({
		mongooseConnection: db
	})
}));

app.locals.appTitle = "FCC Voting app";

// make user ID available in templates
/*app.use(function (req, res, next) {
  	res.locals.currentUser = req.session.userId;
	if (req.session.userId) {
	    res.locals.admin = true;
	}
	next();
});*/

app.use(passport.initialize());
app.use(passport.session());

app.use(express.static(__dirname + '/public'));

//routes
app.use('/', index);

app.all('*', function(req, res) {
	res.send(404);
})

// catch 404 and forward to error handler
app.use(function(req, res, next) {
	var err = new Error('File Not Found');
	err.status = 404;
	next(err);
});

// error handler
// define as the last app.use callback
app.use(function(err, req, res, next) {
	res.status(err.status || 500);
	res.render('error', {
		message: err.message,
		error: {}
	});
});

var server = app.listen(process.env.PORT || 8080, function(){
	var port = server.address().port;
	console.log('App now running on port', port);
});

var shutdown = function() {
	server.close();
}
